//
//  Point.h
//  MacGraphicsStarter
//
//  Created by Kaden Wilkinson on 4/7/15.
//
//

#ifndef __MacGraphicsStarter__Point__
#define __MacGraphicsStarter__Point__

#include <stdio.h>

#endif /* defined(__MacGraphicsStarter__Point__) */
