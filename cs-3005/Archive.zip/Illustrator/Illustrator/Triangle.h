//
//  Triangle.h
//  MacGraphicsStarter
//
//  Created by Kaden Wilkinson on 4/7/15.
//
//

#ifndef __MacGraphicsStarter__Triangle__
#define __MacGraphicsStarter__Triangle__

#include <stdio.h>

#endif /* defined(__MacGraphicsStarter__Triangle__) */
