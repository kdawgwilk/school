//
//  Circle.cpp
//  MacGraphicsStarter
//
//  Created by Kaden Wilkinson on 4/7/15.
//
//

#include "Circle.h"
