//
//  Slider.h
//  MacGraphicsStarter
//
//  Created by Kaden Wilkinson on 4/7/15.
//
//

#ifndef __MacGraphicsStarter__Slider__
#define __MacGraphicsStarter__Slider__

#include <stdio.h>

#endif /* defined(__MacGraphicsStarter__Slider__) */
