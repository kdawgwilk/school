//
//  Shape.h
//  MacGraphicsStarter
//
//  Created by Kaden Wilkinson on 4/7/15.
//
//

#ifndef __MacGraphicsStarter__Shape__
#define __MacGraphicsStarter__Shape__

#include <stdio.h>

#endif /* defined(__MacGraphicsStarter__Shape__) */
