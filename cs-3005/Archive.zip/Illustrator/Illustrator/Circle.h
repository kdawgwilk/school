//
//  Circle.h
//  MacGraphicsStarter
//
//  Created by Kaden Wilkinson on 4/7/15.
//
//

#ifndef __MacGraphicsStarter__Circle__
#define __MacGraphicsStarter__Circle__

#include <stdio.h>

#endif /* defined(__MacGraphicsStarter__Circle__) */
